#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
. .venv/bin/activate
pip install -q -r backend/requirements.txt

export PYTHONPATH=.
PORT="${PORT:-8000}"
exec uvicorn backend.app:app --host "${HOST:-0.0.0.0}" --port "$PORT"
