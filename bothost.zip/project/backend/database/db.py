from __future__ import annotations

import sqlite3
import time
import uuid
from contextlib import contextmanager
from typing import Any, Iterator


def _row(row: sqlite3.Row | None) -> dict[str, Any] | None:
    return dict(row) if row is not None else None


def utc_now() -> float:
    return time.time()


class Database:
    def __init__(self, path: str) -> None:
        self.path = path

    @contextmanager
    def _conn(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def init(self) -> None:
        with self._conn() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    owner_id INTEGER NOT NULL,
                    name TEXT NOT NULL,
                    slug TEXT NOT NULL UNIQUE,
                    main_file TEXT,
                    status TEXT NOT NULL DEFAULT 'stopped',
                    pid INTEGER,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS files (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
                    filename TEXT NOT NULL,
                    size INTEGER NOT NULL,
                    uploaded_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS login_tokens (
                    token TEXT PRIMARY KEY,
                    owner_id INTEGER NOT NULL,
                    expires_at REAL NOT NULL,
                    used INTEGER NOT NULL DEFAULT 0
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS activity_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    action TEXT NOT NULL,
                    actor TEXT NOT NULL,
                    project_id INTEGER,
                    details TEXT,
                    created_at REAL NOT NULL,
                    FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE SET NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS admins (
                    user_id INTEGER PRIMARY KEY,
                    added_at REAL NOT NULL
                )
                """
            )
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS active_users (
                    user_id INTEGER PRIMARY KEY,
                    first_seen REAL NOT NULL
                )
                """
            )

    # ---- admins ----
    def seed_admins(self, user_ids: set[int]) -> None:
        with self._conn() as conn:
            for uid in user_ids:
                conn.execute(
                    "INSERT OR IGNORE INTO admins (user_id, added_at) VALUES (?, ?)", (uid, utc_now())
                )

    def add_admin(self, user_id: int) -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO admins (user_id, added_at) VALUES (?, ?)", (user_id, utc_now())
            )

    def remove_admin(self, user_id: int) -> bool:
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM admins WHERE user_id = ?", (user_id,))
        return cur.rowcount > 0

    def list_admins(self) -> set[int]:
        with self._conn() as conn:
            rows = conn.execute("SELECT user_id FROM admins").fetchall()
        return {int(r["user_id"]) for r in rows}

    def is_admin(self, user_id: int) -> bool:
        with self._conn() as conn:
            row = conn.execute("SELECT 1 FROM admins WHERE user_id = ?", (user_id,)).fetchone()
        return row is not None

    # ---- active users (for broadcast) ----
    def record_active_user(self, user_id: int) -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT OR IGNORE INTO active_users (user_id, first_seen) VALUES (?, ?)", (user_id, utc_now())
            )

    def list_active_users(self) -> list[int]:
        with self._conn() as conn:
            rows = conn.execute("SELECT user_id FROM active_users").fetchall()
        return [int(r["user_id"]) for r in rows]

    # ---- projects ----
    def create_project(self, owner_id: int, name: str, slug: str) -> dict[str, Any]:
        with self._conn() as conn:
            now = utc_now()
            cur = conn.execute(
                "INSERT INTO projects (owner_id, name, slug, status, created_at, updated_at) VALUES (?, ?, ?, 'stopped', ?, ?)",
                (owner_id, name, slug, now, now),
            )
            pid = cur.lastrowid
        return self.get_project(pid)  # type: ignore[arg-type]

    def get_project(self, project_id: int) -> dict[str, Any] | None:
        with self._conn() as conn:
            return _row(conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone())

    def get_project_by_slug(self, slug: str) -> dict[str, Any] | None:
        with self._conn() as conn:
            return _row(conn.execute("SELECT * FROM projects WHERE slug = ?", (slug,)).fetchone())

    def list_projects(self, owner_id: int) -> list[dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM projects WHERE owner_id = ? ORDER BY created_at DESC", (owner_id,)
            ).fetchall()
        return [dict(r) for r in rows]

    def count_projects(self, owner_id: int) -> int:
        with self._conn() as conn:
            row = conn.execute("SELECT COUNT(*) AS c FROM projects WHERE owner_id = ?", (owner_id,)).fetchone()
        return int(row["c"])

    def update_project(self, project_id: int, **changes: Any) -> dict[str, Any] | None:
        if changes:
            changes["updated_at"] = utc_now()
            assignments = ", ".join(f"{k} = ?" for k in changes)
            with self._conn() as conn:
                conn.execute(f"UPDATE projects SET {assignments} WHERE id = ?", (*changes.values(), project_id))
        return self.get_project(project_id)

    def delete_project(self, project_id: int) -> dict[str, Any] | None:
        record = self.get_project(project_id)
        if record:
            with self._conn() as conn:
                conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        return record

    # ---- files ----
    def add_file(self, project_id: int, filename: str, size: int) -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO files (project_id, filename, size, uploaded_at) VALUES (?, ?, ?, ?)",
                (project_id, filename, size, utc_now()),
            )

    def list_files(self, project_id: int) -> list[dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM files WHERE project_id = ? ORDER BY filename", (project_id,)
            ).fetchall()
        return [dict(r) for r in rows]

    # ---- login tokens ----
    def create_login_token(self, owner_id: int, ttl_seconds: int) -> str:
        token = uuid.uuid4().hex + uuid.uuid4().hex
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO login_tokens (token, owner_id, expires_at, used) VALUES (?, ?, ?, 0)",
                (token, owner_id, utc_now() + ttl_seconds),
            )
        return token

    def revoke_all_tokens(self, owner_id: int) -> int:
        with self._conn() as conn:
            cur = conn.execute(
                "UPDATE login_tokens SET used = 1 WHERE owner_id = ? AND used = 0", (owner_id,)
            )
        return cur.rowcount

    def consume_login_token(self, token: str) -> int | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM login_tokens WHERE token = ? AND used = 0 AND expires_at > ?",
                (token, utc_now()),
            ).fetchone()
            if row is None:
                return None
            conn.execute("UPDATE login_tokens SET used = 1 WHERE token = ?", (token,))
        return int(row["owner_id"])

    # ---- activity ----
    def add_activity(self, action: str, actor: str, project_id: int | None = None, details: str = "") -> None:
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO activity_logs (action, actor, project_id, details, created_at) VALUES (?, ?, ?, ?, ?)",
                (action, actor, project_id, details, utc_now()),
            )

    def list_activity(self, limit: int = 50, offset: int = 0) -> list[dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM activity_logs ORDER BY created_at DESC, id DESC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        return [dict(r) for r in rows]
