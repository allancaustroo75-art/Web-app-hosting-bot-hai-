from __future__ import annotations

from fastapi import APIRouter, Cookie, HTTPException
from pydantic import BaseModel

from backend.api.auth import require_session
from backend.database.db import Database
from backend.process.manager import ProcessManager


class FileWriteRequest(BaseModel):
    content: str


class ProjectsAPI:
    def __init__(self, db: Database, pm: ProcessManager) -> None:
        self.db = db
        self.pm = pm

    def router(self) -> APIRouter:
        router = APIRouter(prefix="/api/projects", tags=["projects"])

        @router.get("")
        async def list_projects(bh_session: str | None = Cookie(default=None)):
            session = require_session(bh_session)
            owner_id = session["owner_id"]
            projects = self.db.list_projects(owner_id)
            for p in projects:
                p["runtime_status"] = self.pm.status(p["id"])
            return {"projects": projects}

        @router.get("/{project_id}")
        async def get_project(project_id: int, bh_session: str | None = Cookie(default=None)):
            project = self._owned_project(project_id, bh_session)
            project["runtime_status"] = self.pm.status(project_id)
            project["files"] = self.pm.list_files(project_id)
            return project

        @router.post("/{project_id}/start")
        async def start_project(project_id: int, bh_session: str | None = Cookie(default=None)):
            project = self._owned_project(project_id, bh_session)
            if not project["main_file"]:
                raise HTTPException(status_code=400, detail="No entrypoint (.py) set for this project")
            _, note = await self.pm.start(project_id, project["main_file"])
            self.db.update_project(project_id, status="running")
            self.db.add_activity("start", str(project["owner_id"]), project_id)
            return {"status": "running", "note": note}

        @router.post("/{project_id}/stop")
        async def stop_project(project_id: int, bh_session: str | None = Cookie(default=None)):
            project = self._owned_project(project_id, bh_session)
            await self.pm.stop(project_id)
            self.db.update_project(project_id, status="stopped")
            self.db.add_activity("stop", str(project["owner_id"]), project_id)
            return {"status": "stopped"}

        @router.delete("/{project_id}")
        async def delete_project(project_id: int, bh_session: str | None = Cookie(default=None)):
            project = self._owned_project(project_id, bh_session)
            await self.pm.stop(project_id)
            self.pm.delete(project_id)
            self.db.delete_project(project_id)
            self.db.add_activity("delete", str(project["owner_id"]), project_id)
            return {"ok": True}

        @router.get("/{project_id}/logs")
        async def get_logs(project_id: int, bh_session: str | None = Cookie(default=None)):
            self._owned_project(project_id, bh_session)
            return {"lines": self.pm.tail(project_id, 200)}

        @router.get("/{project_id}/files/{path:path}")
        async def read_file(project_id: int, path: str, bh_session: str | None = Cookie(default=None)):
            self._owned_project(project_id, bh_session)
            try:
                return {"path": path, "content": self.pm.read_file(project_id, path)}
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid path")
            except FileNotFoundError:
                raise HTTPException(status_code=404, detail="File not found")

        @router.put("/{project_id}/files/{path:path}")
        async def write_file(
            project_id: int, path: str, body: FileWriteRequest, bh_session: str | None = Cookie(default=None)
        ):
            project = self._owned_project(project_id, bh_session)
            try:
                self.pm.write_file(project_id, path, body.content)
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid path")
            self.db.add_activity("edit_file", str(project["owner_id"]), project_id, path)
            return {"ok": True}

        return router

    def _owned_project(self, project_id: int, cookie_value: str | None) -> dict:
        session = require_session(cookie_value)
        project = self.db.get_project(project_id)
        if not project or project["owner_id"] != session["owner_id"]:
            raise HTTPException(status_code=404, detail="Project not found")
        return project
