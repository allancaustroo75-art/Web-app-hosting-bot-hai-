from __future__ import annotations

import asyncio

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.config import settings
from backend.database.db import Database
from backend.process.manager import ProcessManager
from backend.services.security import verify_session


class TerminalAPI:
    def __init__(self, db: Database, pm: ProcessManager) -> None:
        self.db = db
        self.pm = pm

    def router(self) -> APIRouter:
        router = APIRouter(tags=["terminal"])

        @router.websocket("/ws/projects/{project_id}/logs")
        async def logs_ws(websocket: WebSocket, project_id: int):
            cookie_value = websocket.cookies.get("bh_session")
            session = verify_session(cookie_value, settings.secret_key) if cookie_value else None
            project = self.db.get_project(project_id)
            if session is None or not project or project["owner_id"] != session["owner_id"]:
                await websocket.close(code=4401)
                return

            await websocket.accept()
            sent = 0
            try:
                while True:
                    lines = self.pm.tail(project_id, 1000)
                    if len(lines) > sent:
                        for line in lines[sent:]:
                            await websocket.send_text(line)
                        sent = len(lines)
                    await asyncio.sleep(1)
            except WebSocketDisconnect:
                return

        return router
