from __future__ import annotations

from fastapi import APIRouter, Cookie, HTTPException, Response
from pydantic import BaseModel

from backend.config import settings
from backend.database.db import Database
from backend.services.security import generate_csrf_token, sign_session, verify_session

SESSION_COOKIE = "bh_session"


class TokenLoginRequest(BaseModel):
    token: str


class AuthAPI:
    def __init__(self, db: Database) -> None:
        self.db = db

    def router(self) -> APIRouter:
        router = APIRouter(prefix="/api/auth", tags=["auth"])

        @router.post("/token-login")
        async def token_login(body: TokenLoginRequest, response: Response):
            owner_id = self.db.consume_login_token(body.token)
            if owner_id is None:
                raise HTTPException(status_code=401, detail="Invalid or expired token")
            csrf = generate_csrf_token()
            session = sign_session({"owner_id": owner_id, "csrf": csrf}, settings.secret_key, settings.session_ttl_seconds)
            response.set_cookie(
                SESSION_COOKIE,
                session,
                httponly=True,
                samesite="lax",
                secure=settings.cookie_secure,
                max_age=settings.session_ttl_seconds,
            )
            self.db.add_activity("login", str(owner_id))
            return {"ok": True, "owner_id": owner_id, "csrf_token": csrf}

        @router.get("/me")
        async def me(bh_session: str | None = Cookie(default=None)):
            session = self._require_session(bh_session)
            return {"owner_id": session["owner_id"]}

        @router.post("/logout")
        async def logout(response: Response):
            response.delete_cookie(SESSION_COOKIE)
            return {"ok": True}

        return router

    def _require_session(self, cookie_value: str | None) -> dict:
        if not cookie_value:
            raise HTTPException(status_code=401, detail="Not authenticated")
        session = verify_session(cookie_value, settings.secret_key)
        if session is None:
            raise HTTPException(status_code=401, detail="Session expired")
        return session


def require_session(cookie_value: str | None) -> dict:
    """Shared helper other routers use to authenticate a request."""
    if not cookie_value:
        raise HTTPException(status_code=401, detail="Not authenticated")
    session = verify_session(cookie_value, settings.secret_key)
    if session is None:
        raise HTTPException(status_code=401, detail="Session expired")
    return session
