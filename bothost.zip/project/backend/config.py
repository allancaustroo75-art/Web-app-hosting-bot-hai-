from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _bool(name: str, default: bool) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in ("1", "true", "yes", "on")


def _list(name: str) -> list[str]:
    v = os.getenv(name, "")
    return [x.strip() for x in v.split(",") if x.strip()]


@dataclass
class Settings:
    bot_token: str = os.getenv("BOT_TOKEN", "")
    admin_user_ids: set[int] = field(default_factory=lambda: {int(x) for x in _list("ADMIN_USER_IDS") if x.isdigit()})
    owner_user_id: int = int(os.getenv("OWNER_USER_ID", "0"))

    secret_key: str = os.getenv("SECRET_KEY", "change-me-in-production")
    database_path: str = os.getenv("DATABASE_PATH", "./data/bothost.db")
    projects_dir: Path = Path(os.getenv("PROJECTS_DIR", "./projects")).resolve()

    dashboard_base_url: str = os.getenv("DASHBOARD_BASE_URL", "http://localhost:8000")
    login_token_ttl_seconds: int = int(os.getenv("LOGIN_TOKEN_TTL_SECONDS", "900"))  # 15 min
    session_ttl_seconds: int = int(os.getenv("SESSION_TTL_SECONDS", str(12 * 3600)))

    max_projects_per_user: int = int(os.getenv("MAX_PROJECTS_PER_USER", "3"))
    max_upload_bytes: int = int(os.getenv("MAX_UPLOAD_BYTES", str(25 * 1024 * 1024)))  # 25 MB

    # Basic resource guardrails applied to every hosted process (Linux only).
    process_cpu_seconds: int = int(os.getenv("PROCESS_CPU_SECONDS", "3600"))
    process_memory_mb: int = int(os.getenv("PROCESS_MEMORY_MB", "256"))

    cors_origins: list[str] = field(default_factory=lambda: _list("CORS_ORIGINS") or ["*"])
    cookie_secure: bool = _bool("COOKIE_SECURE", False)

    host: str = os.getenv("HOST", "0.0.0.0")
    port: int = int(os.getenv("PORT", "8000"))


settings = Settings()
settings.projects_dir.mkdir(parents=True, exist_ok=True)
Path(settings.database_path).parent.mkdir(parents=True, exist_ok=True)
