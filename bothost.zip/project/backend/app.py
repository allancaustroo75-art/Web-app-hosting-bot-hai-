from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.api.auth import AuthAPI
from backend.api.projects import ProjectsAPI
from backend.api.terminal import TerminalAPI
from backend.bot.runner import BotRunner
from backend.config import settings
from backend.database.db import Database
from backend.process.manager import ProcessManager

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger(__name__)

db = Database(settings.database_path)
pm = ProcessManager(settings.projects_dir, settings.process_cpu_seconds, settings.process_memory_mb)
bot_runner = BotRunner(db, pm, settings)


@asynccontextmanager
async def lifespan(app: FastAPI):
    db.init()
    try:
        await bot_runner.start()
    except Exception:
        log.exception("Telegram bot failed to start; API will remain available without it")
    yield
    await bot_runner.stop()


app = FastAPI(title="BotHost", version="1.0.0", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type"],
)


@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    return response


app.include_router(AuthAPI(db).router())
app.include_router(ProjectsAPI(db, pm).router())
app.include_router(TerminalAPI(db, pm).router())


@app.get("/health", tags=["system"])
async def health() -> dict[str, str | bool]:
    return {"status": "ok", "telegram_configured": bot_runner.configured}


frontend_dir = Path(__file__).resolve().parent.parent / "frontend"
if frontend_dir.exists():

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(frontend_dir / "index.html")

    @app.get("/{page}.html", include_in_schema=False)
    async def frontend_page(page: str) -> FileResponse:
        target = frontend_dir / f"{page}.html"
        if target.exists():
            return FileResponse(target)
        return FileResponse(frontend_dir / "index.html")

    app.mount("/", StaticFiles(directory=frontend_dir), name="frontend")
