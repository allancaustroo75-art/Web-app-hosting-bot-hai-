# BotHost — Telegram-driven Python Bot Hosting

Upload a `.py`, `.txt`/`.json`, or `.zip` file to your Telegram bot and it gets
turned into a managed project: dependencies auto-installed into an isolated
virtualenv, then started/stopped/deleted from either Telegram or a web
dashboard. The dashboard is unlocked with a one-time link the bot sends you
in chat (`/dashboard`) — no separate password to remember.

This is an original implementation inspired by the general "upload a bot,
we host it" pattern — it does not reuse any other service's name, branding,
or copy.

## How it works

```text
Telegram admin ──document──> Bot ──> ProcessManager ──> isolated venv per project
                                            │
                                            ├──> subprocess (the hosted bot itself)
                                            └──> live stdout/stderr tail
Browser dashboard ──token-login──> FastAPI ──> same ProcessManager + SQLite metadata
```

- SQLite (`bothost.db`) stores project metadata, uploaded-file records, login
  tokens and an activity log — never file content or secrets.
- Each project gets its own directory under `PROJECTS_DIR/<id>/` and its own
  `.venv`, so dependencies don't clash between projects.
- Hosted processes run with **best-effort CPU-time and memory limits**
  (`resource.setrlimit`, Linux only) and are grouped so `stop` can kill the
  whole process tree. This is *not* a full sandbox — see Security below.

## Telegram commands

- `/start` — welcome + persistent menu keyboard.
- Send a document directly — starts the "create project" flow.
- `/myfiles` — list your projects with status, tap one to Start/Stop/Delete.
- `/status` — project counts.
- `/dashboard` — sends a one-time login link for the web dashboard.
- `/addadmin <id>`, `/removeadmin <id>`, `/listadmins` — owner-only admin management.
- `/broadcast <text>` — owner-only, messages every user who has ever run `/start`.

## Menu keyboard

📁 My Files · 📤 Upload File · ✏️ Edit Files · 🗑️ Delete Folder · ▶️ Run Module ·
📊 Status · 📋 My Logs · 🔄 Revoke Token · 🌐 Web Dashboard

`Edit Files` walks you through picking a project, then a file — the bot shows the
current content and you reply with the new content to save it. `My Logs` tails the
last ~60 lines of a running/stopped project. `Revoke Token` invalidates any
outstanding dashboard login links for that user.

## Multi-language support

Projects can be Python (`.py`, run in an isolated per-project venv) or Node
(`.js`, run with the system `node`). If a project's upload includes
`requirements.txt` and/or `package.json`, both are installed automatically.
On first run, a quick pre-check catches an obvious `ModuleNotFoundError` and
auto-installs the missing package (best-effort, single attempt — mapped
through a small import-name → PyPI-package table for cases like
`telebot` → `pyTelegramBotAPI`).

## Web dashboard

- **Login** (`login.html`) — auto-logs in via `?token=` from the bot's
  `/dashboard` link, or accepts a pasted token.
- **Overview** — project counts, running/stopped breakdown.
- **Projects** — start/stop/delete any project.
- **Project detail** — file browser, a basic code editor (save writes
  directly to the project's file on disk), and a live terminal that streams
  the running process's combined stdout/stderr over a WebSocket.

## Quick start

```bash
cp .env.example .env
# fill in BOT_TOKEN, ADMIN_USER_IDS, SECRET_KEY
./start.sh
```

Open `http://localhost:8000`, message your bot `/start` on Telegram, and
upload a `.py` file.

## Security notes — read before exposing this publicly

- **Only IDs in `ADMIN_USER_IDS` can use the bot or log in.** Fail-closed if
  the list is empty.
- **Uploaded code runs as a real subprocess with your server's permissions**,
  restricted only by best-effort CPU/memory rlimits. There is **no
  filesystem, network, or syscall sandbox**. Do not open this to untrusted
  users without adding real isolation (Docker/gVisor/nsjail, a seccomp
  profile, and no outbound network by default) — otherwise anyone who can
  upload a file can run arbitrary code on your machine.
- Dashboard login tokens are single-use, short-lived (15 min default), and
  bound to the Telegram user who requested them.
- Sessions are HMAC-signed cookies (`SECRET_KEY`), `HttpOnly`, `SameSite=Lax`,
  and expire after `SESSION_TTL_SECONDS`.
- File uploads are restricted by extension and size; filenames are
  sanitized and zip extraction is guarded against path traversal (zip-slip).
- Set `COOKIE_SECURE=true` and serve over HTTPS in production; set
  `CORS_ORIGINS` to your exact dashboard origin(s).

## Project structure

```text
project/
├── backend/
│   ├── app.py            FastAPI app, wiring, static frontend serving
│   ├── config.py         env-var settings
│   ├── bot/               Telegram bot (handlers.py, runner.py)
│   ├── process/manager.py per-project venv + subprocess lifecycle
│   ├── api/                auth.py, projects.py, terminal.py (websocket)
│   ├── database/db.py     SQLite
│   └── services/           security.py (sessions), naming.py (sanitizing)
├── frontend/               login/dashboard/projects/project pages + app.js
├── .env.example
├── start.sh
└── README.md
```
