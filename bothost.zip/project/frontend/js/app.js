const API = window.BOTHOST_API || "";

async function api(path, opts = {}) {
  const res = await fetch(`${API}${path}`, {
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    ...opts,
  });
  if (res.status === 401) {
    window.location.href = "login.html";
    throw new Error("Not authenticated");
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed (${res.status})`);
  }
  return res.json();
}

document.addEventListener("DOMContentLoaded", () => {
  const logoutLink = document.getElementById("logoutLink");
  if (logoutLink) {
    logoutLink.addEventListener("click", async (e) => {
      e.preventDefault();
      await api("/api/auth/logout", { method: "POST" });
      window.location.href = "login.html";
    });
  }
});

function statusDot(status) {
  return `<span class="dot ${status === "running" ? "running" : "stopped"}"></span>`;
}

async function renderDashboard() {
  const { projects } = await api("/api/projects");
  const running = projects.filter((p) => p.runtime_status === "running").length;

  document.getElementById("stats").innerHTML = `
    <div class="card"><div class="stat-value">${projects.length}</div><div class="stat-label">Total Projects</div></div>
    <div class="card"><div class="stat-value">${running}</div><div class="stat-label">Running</div></div>
    <div class="card"><div class="stat-value">${projects.length - running}</div><div class="stat-label">Stopped</div></div>
  `;

  const list = document.getElementById("projectList");
  if (projects.length === 0) {
    list.innerHTML = "No projects yet — send a file to the bot on Telegram to get started.";
    return;
  }
  list.innerHTML = projects
    .map(
      (p) => `
      <div class="project-row">
        <div>${statusDot(p.runtime_status)}<a href="project.html?id=${p.id}">${p.name}</a></div>
        <div class="muted">${p.runtime_status}</div>
      </div>`
    )
    .join("");
}

async function renderProjectsPage() {
  const { projects } = await api("/api/projects");
  const list = document.getElementById("projectListFull");
  if (projects.length === 0) {
    list.innerHTML = "No projects yet — send a file to the bot on Telegram to get started.";
    return;
  }
  list.innerHTML = projects
    .map(
      (p) => `
      <div class="project-row">
        <div>${statusDot(p.runtime_status)}<a href="project.html?id=${p.id}">${p.name}</a></div>
        <div>
          <button class="btn" onclick="toggleProject(${p.id}, '${p.runtime_status}')">${p.runtime_status === "running" ? "Stop" : "Start"}</button>
          <button class="btn danger" onclick="deleteProject(${p.id})">Delete</button>
        </div>
      </div>`
    )
    .join("");
}

async function toggleProject(id, currentStatus) {
  const action = currentStatus === "running" ? "stop" : "start";
  await api(`/api/projects/${id}/${action}`, { method: "POST" });
  renderProjectsPage();
}

async function deleteProject(id) {
  if (!confirm("Delete this project? This cannot be undone.")) return;
  await api(`/api/projects/${id}`, { method: "DELETE" });
  renderProjectsPage();
}

let currentProjectId = null;
let ws = null;

async function renderProjectPage() {
  const params = new URLSearchParams(window.location.search);
  currentProjectId = params.get("id");
  const project = await api(`/api/projects/${currentProjectId}`);

  document.getElementById("projectName").textContent = project.name;
  document.getElementById("projectMeta").textContent =
    `Entrypoint: ${project.main_file || "not set"} · Status: ${project.runtime_status}`;

  document.getElementById("startBtn").onclick = async () => {
    await api(`/api/projects/${currentProjectId}/start`, { method: "POST" });
    renderProjectPage();
  };
  document.getElementById("stopBtn").onclick = async () => {
    await api(`/api/projects/${currentProjectId}/stop`, { method: "POST" });
    renderProjectPage();
  };
  document.getElementById("deleteBtn").onclick = async () => {
    if (!confirm("Delete this project?")) return;
    await api(`/api/projects/${currentProjectId}`, { method: "DELETE" });
    window.location.href = "projects.html";
  };

  document.getElementById("fileList").innerHTML = project.files
    .map((f) => `<a href="#" onclick="openFile('${f}'); return false;">${f}</a>`)
    .join("") || "No files.";

  connectTerminal(currentProjectId);
}

async function openFile(path) {
  const data = await api(`/api/projects/${currentProjectId}/files/${encodeURIComponent(path)}`);
  document.getElementById("editorCard").style.display = "block";
  document.getElementById("editorFileName").textContent = path;
  document.getElementById("editorArea").value = data.content;
  document.getElementById("saveFileBtn").onclick = async () => {
    await api(`/api/projects/${currentProjectId}/files/${encodeURIComponent(path)}`, {
      method: "PUT",
      body: JSON.stringify({ content: document.getElementById("editorArea").value }),
    });
    alert("Saved.");
  };
}

function connectTerminal(projectId) {
  const term = document.getElementById("terminal");
  const proto = window.location.protocol === "https:" ? "wss" : "ws";
  const base = API ? API.replace(/^https?/, proto) : `${proto}://${window.location.host}`;
  ws = new WebSocket(`${base}/ws/projects/${projectId}/logs`);
  ws.onmessage = (event) => {
    term.textContent += event.data + "\n";
    term.scrollTop = term.scrollHeight;
  };
  ws.onerror = () => {
    term.textContent += "[terminal connection error]\n";
  };
}
