// Same-origin by default. Set this if the frontend is hosted separately (e.g. Netlify).
window.BOTHOST_API = window.BOTHOST_API || "";
