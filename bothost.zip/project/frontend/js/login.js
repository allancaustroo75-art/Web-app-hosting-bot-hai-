const API = window.BOTHOST_API || "";

async function doLogin(token) {
  const statusEl = document.getElementById("status");
  statusEl.textContent = "Logging in…";
  try {
    const res = await fetch(`${API}/api/auth/token-login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ token }),
    });
    if (!res.ok) throw new Error("Invalid or expired token");
    window.location.href = "dashboard.html";
  } catch (err) {
    statusEl.textContent = "❌ " + err.message + ". Send /dashboard to the bot for a new link.";
  }
}

const params = new URLSearchParams(window.location.search);
const urlToken = params.get("token");
if (urlToken) {
  doLogin(urlToken);
}

document.getElementById("loginBtn").addEventListener("click", () => {
  const val = document.getElementById("tokenInput").value.trim();
  if (val) doLogin(val);
});
